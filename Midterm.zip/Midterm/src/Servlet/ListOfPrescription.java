package Servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Java_Classes.Person;
import Java_Classes.Prescription;


@WebServlet("/ListOfPrescription")
public class ListOfPrescription extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Override
	public void init(ServletConfig config) throws ServletException {
	super.init(config);
	
	ServletContext appContext = getServletContext();
	/*
	 * Create a doctor with name "michael", phoneNumber "888-888-8888" licenseID "12345", specialty "neurology", username "admin" and password "admin" in the init() method.
	 *  Also create at least two patients, two prescriptions and five drugs.
	 */
	
	// creating Doctor
	Person doctor1 = new Person(4,12345, "Michael", "888-888-8888", "admin", "admin", true, "Neurology");
//	List<Person> docList = new ArrayList<Person>();
//	docList.add(doctor1);
//	appContext.setAttribute("docList", docList);
	
	
	// creating two patients
	Person patient1 = new Person(1,11, "Naif", "3233170924", "Naif", "1", false);
	Person patient2 = new Person(2,224, "Sam", "3232323990", "Sam", "2", false);
	Person patient3 = new Person(3,393, "Moh", "0000000000", "Moh", "3", false);
	
	List<Person> patientsList = new ArrayList<Person>();
	patientsList.add(patient1);
	patientsList.add(patient2);
	patientsList.add(patient3);
	appContext.setAttribute("patientsList", patientsList);
	
	
	String drug1 = "D1";
	String drug2 = "D2";
	String drug3 = "D3";
	String drug4 = "D4";
	String drug5 = "D5";
	
	
	List<String> drugs = new ArrayList<>();
	drugs.add(drug1);
	drugs.add(drug2);
	drugs.add(drug3);
	drugs.add(drug4);
	drugs.add(drug5);
	
	
	
	Prescription pre1 = new Prescription(1 ,110, doctor1.getName(), patient1.getName(), new String[] {drug4,drug2}, 3);
	Prescription pre2 = new Prescription(2 ,435, doctor1.getName(), patient2.getName(), new String[] {drug3,drug1} , 4);
	Prescription pre3 = new Prescription(3 ,789, doctor1.getName(), patient3.getName(), new String[] {drug4,drug5}, 1);
	List<Prescription> prescriptionList = new ArrayList<Prescription>();
	prescriptionList.add(pre1);
	prescriptionList.add(pre2);
	prescriptionList.add(pre3);
	appContext.setAttribute("prescriptionList", prescriptionList);	
	
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		if( request.getSession().getAttribute( "id" ) == null ) {
            response.sendRedirect( "Login" );
            return;
        }
		
		List<Prescription> prescriptionList = (List<Prescription>) getServletContext().getAttribute("prescriptionList");
		
		
		request.setAttribute("prescriptionList", prescriptionList);
		request.getRequestDispatcher("/WEB-INF/PrescriptionList.jsp").forward(request, response);;
		
		
	}

	

}
