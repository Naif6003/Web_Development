package Servlet;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Java_Classes.Person;
import Java_Classes.Prescription;

@WebServlet(urlPatterns="/Add")
public class Add extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if( request.getSession().getAttribute( "id" ) == null ) {
            response.sendRedirect( "Login" );
            return;
        }
		
		
		List<Person> patient = (List<Person>) getServletContext().getAttribute("patientsList");
		request.setAttribute("patient", patient);
		
		
//		List<Person> doctor = (List<Person>) getServletContext().getAttribute("docList");
//		request.setAttribute("doctor", doctor);
		
		
		request.getRequestDispatcher("/WEB-INF/Add.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String patientName = request.getParameter("patients");
		String doctorName = request.getParameter("doctors");
		
		String drug1 = request.getParameter("drug1");
		String drug2 = request.getParameter("drug2");
		String drug3 = request.getParameter("drug3");
		
		List<Prescription> pres = (List<Prescription>)getServletContext().getAttribute("prescriptionList");
		
		 int newId = getNewId(pres);
	     
	     
		 Prescription newPre = new Prescription(newId, 000, doctorName, patientName, new String[]{drug1,drug2} , 1);
	     
	     
	     
		 pres.add(newPre);
	     
	     response.sendRedirect("View?id="+ newId);
		
	}
	public int getNewId(List<Prescription> existingEvents){
		
		int newId = existingEvents.size();
		
		HashSet<Integer> existingIds = new HashSet<>();
		
		for(Prescription event : existingEvents){
			 
			existingIds.add(event.id);
		}
		while(existingIds.contains(newId)){
			newId++;
		}
		return newId;
	}


}
