package Java_Classes;

public class Prescription {
	
	//prescriptionID, doctor, patient, list of drugnames and their quantity
	public int id;
	int prescriptionID;
	String doctor;
	String patient;
	String[] drugs;
	int quantity;
	
	public Prescription(int id,int prescriptionID, String doctor, String patient, String[] strings, int quantity) {
		this.id = id;
		this.prescriptionID = prescriptionID;
		this.doctor = doctor;
		this.patient = patient;
		this.drugs = strings;
		this.quantity = quantity;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPrescriptionID() {
		return prescriptionID;
	}
	public void setPrescriptionID(int prescriptionID) {
		this.prescriptionID = prescriptionID;
	}
	
	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}

	public String getPatient() {
		return patient;
	}
	public void setPatient(String patient) {
		this.patient = patient;
	}
	public String[] getDrugs() {
		return drugs;
	}
	public void setDrugs(String[] drugs) {
		this.drugs = drugs;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
