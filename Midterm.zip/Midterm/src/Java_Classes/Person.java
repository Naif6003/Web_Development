
package Java_Classes;

public class Person {

//	Both doctors and patients share the following fields: name, phoneNumber, username, password
	public int id;
	int patientID;
	int licenseID;
	String name;
	String phoneNum;
	String userName;
	public String password;
	Boolean isDoctor;
	String specialty;
	
	
	public Person(int id,int patientID,String name, String phoneNum, String userName, String password, Boolean isDoctor) {
		this.id = id ;
		this.patientID = patientID;
		this.name = name;
		this.phoneNum = phoneNum;
		this.userName = userName;
		this.password = password;
		this.isDoctor = isDoctor;
	}
	
	
	public Person(int id,int licenseID,String name, String phoneNum, String userName, String password, Boolean isDoctor, String specialty) {
		this.id=id;
		this.licenseID = licenseID;
		this.name = name;
		this.phoneNum = phoneNum;
		this.userName = userName;
		this.password = password;
		this.isDoctor = isDoctor;
		this.specialty = specialty;
	}
	public int getPatientID() {
		return patientID;
	}


	public void setPatientID(int patientID) {
		this.patientID = patientID;
	}


	public int getLicenseID() {
		return licenseID;
	}


	public void setLicenseID(int licenseID) {
		this.licenseID = licenseID;
	}


	public String getSpecialty() {
		return specialty;
	}


	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Boolean getIsDoctor() {
		return isDoctor;
	}
	public void setIsDoctor(Boolean isDoctor) {
		this.isDoctor = isDoctor;
	}
}

