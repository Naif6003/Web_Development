package The_Servlet_Package;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Java_Class.Event_Obj;
import Java_Class.Organization_Obj;
import Java_Class.User_Obj;


/**
 * Servlet implementation class ViewEachEvent
 */
@WebServlet(urlPatterns = "/Each_Event")
public class Each_Event extends HttpServlet {
	
	
	public static int a = 3;


	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		Date date = new Date();
		request.setAttribute("date", date);
		
		
		String id = request.getParameter("id");

		int event_Id = Integer.parseInt(id);

		// (events) the list variable in the (ListEvents) class.
		List<Event_Obj> events = (List<Event_Obj>)getServletContext().getAttribute("events");
		// Passing the Quiz object to the jsp View by using request.setAttribute
		Event_Obj event = events.get(event_Id);
		
		List<User_Obj> user_List = (List<User_Obj>)getServletContext().getAttribute("president_List");
		User_Obj the_user_List = user_List.get(event_Id);
		request.setAttribute("the_user_List", the_user_List);

		
		String[] arr = (String[]) getServletContext().getAttribute("member_List");
		request.setAttribute("arr", arr);
		
		
		List<Organization_Obj> list = (List<Organization_Obj>) getServletContext().getAttribute("org_List");
		// Passing the Quiz object to the jsp View by using request.setAttribute
		Organization_Obj org_list = list.get(event_Id);
		request.setAttribute("org_List", org_list);
		
		
		request.setAttribute("id", id);
		request.setAttribute("event", event);
		request.getRequestDispatcher("/WEB-INF/Event_Details.jsp").forward(request, response);
	}

	
}
