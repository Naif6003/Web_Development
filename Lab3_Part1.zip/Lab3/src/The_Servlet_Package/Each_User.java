package The_Servlet_Package;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Java_Class.User_Obj;

/**
 * Servlet implementation class Users_Info
 */
@WebServlet("/Each_User")
public class Each_User extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		Date date = new Date();
		request.setAttribute("date", date);
		
		String id = request.getParameter("id");
		int enevt_Id = Integer.parseInt(id);
		
		List<User_Obj> user_List =  (List<User_Obj>) getServletContext().getAttribute("user_List");
		User_Obj the_User_List = user_List.get(enevt_Id);
		
		request.setAttribute("id", id);
		
		request.setAttribute("the_User_List", the_User_List);
		request.getRequestDispatcher("/WEB-INF/User_Details.jsp").forward(request, response);
	}

	

}
