package Java_Class;

public class Organization_Obj{
	
	String org_Type;
	User_Obj org_President;
	User_Obj org_Secrtary;

	
	public Organization_Obj(String type, User_Obj president, User_Obj secretary){
		
		this.org_Type = type;
		this.org_President = president;
		this.org_Secrtary = secretary;
	}

	public String getOrg_Type() {
		return org_Type;
	}

	public void setOrg_Type(String org_Type) {
		this.org_Type = org_Type;
	}

	public User_Obj getOrg_President() {
		return org_President;
	}

	public void setOrg_President(User_Obj org_President) {
		this.org_President = org_President;
	}

	public User_Obj getOrg_Secrtary() {
		return org_Secrtary;
	}

	public void setOrg_Secrtary(User_Obj org_Secrtary) {
		this.org_Secrtary = org_Secrtary;
	}
	
}

