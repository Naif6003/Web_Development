package Java_Class;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class ViewEvent
 */
@WebServlet(urlPatterns="/Events", loadOnStartup = 1 )
public class Events extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
	super.init(config);
	
	ServletContext appContext = getServletContext();
	

	
	Calendar start_Date = Calendar.getInstance();
	start_Date.set(2016, 5, 10);
	
	Calendar end_Date = Calendar.getInstance();
	end_Date.set(2016, 5, 15);
	
	
	
	
	
	User_Obj user_1 = new User_Obj("Naif", 305080742 , 'M');
	User_Obj user_2 = new User_Obj("Michael", 305080742 , 'M');
	User_Obj user_3 = new User_Obj("Ann", 305080742 , 'F');
	User_Obj user_4 = new User_Obj("Rose", 305080742 , 'F');
	
	List<User_Obj> user_List = new ArrayList<User_Obj>();
	user_List.add(user_1);
	user_List.add(user_2);
	user_List.add(user_3);
	user_List.add(user_4);
	
	
	appContext.setAttribute("user_List", user_List);
	
	
	
	User_Obj president_1 = new User_Obj("The President #1", 000000 , 'M');
	User_Obj president_2 = new User_Obj("The President #2", 000000 , 'F');
	User_Obj president_3 = new User_Obj("The President #3", 000000 , 'F');
	User_Obj president_4 = new User_Obj("The President #4", 000000 , 'M');
	
	List<User_Obj> president_List = new ArrayList<User_Obj>();
	president_List.add(president_1);
	president_List.add(president_2);
	president_List.add(president_3);
	president_List.add(president_4);
	
	
	appContext.setAttribute("president_List", president_List);
	
	
	User_Obj secretary_1 = new User_Obj("Secretary #1", 000000 , 'M');
	User_Obj secretary_2 = new User_Obj("Secretary #2", 000000 , 'F');
	User_Obj secretary_3 = new User_Obj("Secretary #3", 000000 , 'F');
	User_Obj secretary_4 = new User_Obj("Secretary #4", 000000 , 'M');
	
	List<User_Obj> secretary_List = new ArrayList<User_Obj>();
	secretary_List.add(secretary_1);
	secretary_List.add(secretary_2);
	secretary_List.add(secretary_3);
	secretary_List.add(secretary_4);
	
	
	appContext.setAttribute("secretary_List", secretary_List);
	
	
	
	Organization_Obj event_Org_1 = new Organization_Obj("Sport", president_1,secretary_3);
	Organization_Obj event_Org_2 = new Organization_Obj("Art", president_2, secretary_2);
	Organization_Obj event_Org_3 = new Organization_Obj("Science", president_3, secretary_4);
	Organization_Obj event_Org_4 = new Organization_Obj("Sport", president_4 , secretary_1);
	
	List<Organization_Obj> org_List = new ArrayList<Organization_Obj>();
	org_List.add(event_Org_1);
	org_List.add(event_Org_2);
	org_List.add(event_Org_3);
	org_List.add(event_Org_4);
	
	
	appContext.setAttribute("org_List", org_List);
	
//	String[] member_List = {"John","Michael","Jose"};
	
	Event_Obj event_1 = new Event_Obj("Soccer",
			"In this event, students would form two teams and play soccer on the university's soccer field.", 20, event_Org_1);
	Event_Obj event_2 = new Event_Obj("Art", 
			"In this event, student will learn how to draw shapes around the university's main walk",  10, event_Org_2);
	Event_Obj event_3 = new Event_Obj("Computer", 
			"We Rocks. In this event, student will be sharing knowladge about computer science field.",  15, event_Org_3);
	Event_Obj event_4 = new Event_Obj("Gameing", 
			"Student will paly all the time. All games are allowed in here. Enjoy",  13, event_Org_4);
	

	List<Event_Obj> events = new ArrayList<Event_Obj>();
	events.add(event_1);
	events.add(event_2);
	events.add(event_3);
	events.add(event_4);
	
	
	appContext.setAttribute("events", events);	
	}
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		List<Event_Obj> theEvents = (List<Event_Obj>)getServletContext().getAttribute("events");
		
		Date date = new Date();
		request.setAttribute("date", date);
		
		
		
		
		
		request.setAttribute("theEvents", theEvents);
		request.getRequestDispatcher("/WEB-INF/All_Events.jsp").forward(request, response);;
			
	}


	

}
