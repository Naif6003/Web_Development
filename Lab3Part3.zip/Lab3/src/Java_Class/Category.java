package Java_Class;

public enum Category {
	Health, SCIENCE, SPORT, ART, ENTERTAINMENT
}