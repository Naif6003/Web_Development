# CSULA-CS3220-Maven-J2EE-Backend-Starter
Vanilla J2EE Maven project with tomcat7 plugin pre-configured

See [Wiki](https://github.com/mhsu0020/CSULA-CS3220-Fall2016/wiki/Getting-Started-With-Maven-MVNW) for more info on how to get started.
